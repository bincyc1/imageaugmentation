# Contributing to Augmentor

Thanks for your interest in Augmentor.

For guidelines on how to contribute, either by fixing bugs through pull requests or filing bug reports, see [contribution-guide.org](http://www.contribution-guide.org/)!