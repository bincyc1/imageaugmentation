Auto Generated Documentation
****************************

.. automodule:: Augmentor

Module by Module Documentation
==============================

Documentation of the Pipeline module
------------------------------------

.. automodule:: Augmentor.Pipeline
    :members:
    :undoc-members:

Documentation of the Operations module
--------------------------------------

.. automodule:: Augmentor.Operations
    :members:
    :undoc-members:

Documentation of the ImageUtilities module
------------------------------------------

.. automodule:: Augmentor.ImageUtilities
    :members:
    :undoc-members:
