Augmentor
=========

An image augmentation library for machine learning. See `<http://augmentor.readthedocs.io/>`_ for documentation.